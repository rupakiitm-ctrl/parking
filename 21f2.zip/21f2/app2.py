from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'my-secret-key'

# Database setup
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///parking_app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# User table
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String, unique=True, nullable=False)
    password = db.Column(db.String, nullable=False)
    role = db.Column(db.String, nullable=False, default='user')
    created_at = db.Column(db.String, default=lambda: datetime.now().isoformat())

# Parking lot table
class ParkingLot(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    prime_location_name = db.Column(db.String, nullable=False)
    price = db.Column(db.Float, nullable=False)
    address = db.Column(db.String, nullable=False)
    pin_code = db.Column(db.String, nullable=False)
    maximum_number_of_spots = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.String, default=lambda: datetime.now().isoformat())

# Parking spot table
class ParkingSpot(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    lot_id = db.Column(db.Integer, nullable=False)
    spot_number = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String, nullable=False, default='A')
    created_at = db.Column(db.String, default=lambda: datetime.now().isoformat())

# Reservation table
class Reservation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    spot_id = db.Column(db.Integer, nullable=False)
    user_id = db.Column(db.Integer, nullable=False)
    parking_timestamp = db.Column(db.String, default=lambda: datetime.now().isoformat())
    leaving_timestamp = db.Column(db.String)
    parking_cost = db.Column(db.Float)
    status = db.Column(db.String, nullable=False, default='active')

# Make tables and admin user
with app.app_context():
    db.create_all()
    admin = User.query.filter_by(username='admin').first()
    if not admin:
        admin = User(username='admin', password='admin123', role='admin')
        db.session.add(admin)
        db.session.commit()

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username, password=password).first()
        if user:
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            if user.role == 'admin':
                return redirect('/admin/dashboard')
            else:
                return redirect('/user/dashboard')
        else:
            flash('Wrong username or password!')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user:
            flash('Username already taken!')
            return render_template('register.html')
        new_user = User(username=username, password=password, role='user')
        db.session.add(new_user)
        db.session.commit()
        flash('Registration successful! Please login.')
        return redirect('/login')
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

@app.route('/admin/dashboard')
def admin_dashboard():
    if 'role' not in session or session['role'] != 'admin':
        return redirect('/login')
    lots = ParkingLot.query.all()
    spots = ParkingSpot.query.all()
    users = User.query.filter_by(role='user').all()
    total_lots = len(lots)
    total_spots = len(spots)
    occupied_spots = len([s for s in spots if s.status == 'O'])
    available_spots = total_spots - occupied_spots
    total_users = len(users)
    return render_template('admin_dashboard.html',
        total_lots=total_lots,
        total_spots=total_spots,
        occupied_spots=occupied_spots,
        available_spots=available_spots,
        total_users=total_users,
        lots=lots)

@app.route('/admin/create_lot', methods=['GET', 'POST'])
def create_lot():
    if 'role' not in session or session['role'] != 'admin':
        return redirect('/login')
    if request.method == 'POST':
        location_name = request.form['location_name']
        price = float(request.form['price'])
        address = request.form['address']
        pin_code = request.form['pin_code']
        num_spots = int(request.form['num_spots'])
        lot = ParkingLot(
            prime_location_name=location_name,
            price=price,
            address=address,
            pin_code=pin_code,
            maximum_number_of_spots=num_spots
        )
        db.session.add(lot)
        db.session.commit()
        # Add spots
        for i in range(1, num_spots + 1):
            spot = ParkingSpot(lot_id=lot.id, spot_number=i, status='A')
            db.session.add(spot)
        db.session.commit()
        flash('Parking lot created successfully!')
        return redirect('/admin/dashboard')
    return render_template('create_lot.html')

@app.route('/admin/edit_lot/<int:lot_id>', methods=['GET', 'POST'])
def edit_lot(lot_id):
    if 'role' not in session or session['role'] != 'admin':
        return redirect('/login')
    lot = ParkingLot.query.get(lot_id)
    if not lot:
        flash('Parking lot not found!')
        return redirect('/admin/dashboard')
    if request.method == 'POST':
        lot.prime_location_name = request.form['location_name']
        lot.price = float(request.form['price'])
        lot.address = request.form['address']
        lot.pin_code = request.form['pin_code']
        new_num_spots = int(request.form['num_spots'])
        current_spots = ParkingSpot.query.filter_by(lot_id=lot_id).count()
        lot.maximum_number_of_spots = new_num_spots
        db.session.commit()
        if new_num_spots > current_spots:
            for i in range(current_spots + 1, new_num_spots + 1):
                spot = ParkingSpot(lot_id=lot_id, spot_number=i, status='A')
                db.session.add(spot)
            db.session.commit()
        elif new_num_spots < current_spots:
            available_spots = ParkingSpot.query.filter_by(lot_id=lot_id, status='A').all()
            spots_to_remove = current_spots - new_num_spots
            if len(available_spots) >= spots_to_remove:
                for spot in sorted(available_spots, key=lambda x: -x.spot_number)[:spots_to_remove]:
                    db.session.delete(spot)
                db.session.commit()
            else:
                flash('Cannot reduce spots - some spots are occupied!')
                return render_template('edit_lot.html', lot=lot)
        flash('Parking lot updated successfully!')
        return redirect('/admin/dashboard')
    return render_template('edit_lot.html', lot=lot)

@app.route('/admin/delete_lot/<int:lot_id>')
def delete_lot(lot_id):
    if 'role' not in session or session['role'] != 'admin':
        return redirect('/login')
    lot = ParkingLot.query.get(lot_id)
    if not lot:
        flash('Parking lot not found!')
        return redirect('/admin/dashboard')
    occupied_count = ParkingSpot.query.filter_by(lot_id=lot_id, status='O').count()
    if occupied_count > 0:
        flash('Cannot delete parking lot - some spots are occupied!')
    else:
        ParkingSpot.query.filter_by(lot_id=lot_id).delete()
        db.session.delete(lot)
        db.session.commit()
        flash('Parking lot deleted successfully!')
    return redirect('/admin/dashboard')

@app.route('/admin/view_spots/<int:lot_id>')
def view_spots(lot_id):
    if 'role' not in session or session['role'] != 'admin':
        return redirect('/login')
    lot = ParkingLot.query.get(lot_id)
    spots = ParkingSpot.query.filter_by(lot_id=lot_id).order_by(ParkingSpot.spot_number).all()
    return render_template('view_spots.html', lot=lot, spots=spots)

@app.route('/admin/users')
def view_users():
    if 'role' not in session or session['role'] != 'admin':
        return redirect('/login')
    users = User.query.filter_by(role='user').order_by(User.created_at.desc()).all()
    return render_template('view_users.html', users=users)

@app.route('/user/dashboard')
def user_dashboard():
    if 'role' not in session or session['role'] != 'user':
        return redirect('/login')
    user_id = session['user_id']
    active_reservation = Reservation.query.filter_by(user_id=user_id, status='active').first()
    history = Reservation.query.filter_by(user_id=user_id).order_by(Reservation.parking_timestamp.desc()).limit(10).all()
    lots = ParkingLot.query.all()
    available_lots = []
    for lot in lots:
        available = ParkingSpot.query.filter_by(lot_id=lot.id, status='A').count()
        if available > 0:
            available_lots.append((lot, available))
    return render_template('user_dashboard.html',
        active_reservation=active_reservation,
        history=history,
        available_lots=available_lots)

@app.route('/user/book_spot/<int:lot_id>')
def book_spot(lot_id):
    if 'role' not in session or session['role'] != 'user':
        return redirect('/login')
    user_id = session['user_id']
    active_reservation = Reservation.query.filter_by(user_id=user_id, status='active').first()
    if active_reservation:
        flash('You already have an active parking reservation!')
        return redirect('/user/dashboard')
    spot = ParkingSpot.query.filter_by(lot_id=lot_id, status='A').order_by(ParkingSpot.spot_number).first()
    if not spot:
        flash('No available spots in this parking lot!')
        return redirect('/user/dashboard')
    reservation = Reservation(spot_id=spot.id, user_id=user_id, status='active')
    spot.status = 'O'
    db.session.add(reservation)
    db.session.commit()
    flash('Parking spot booked successfully!')
    return redirect('/user/dashboard')

@app.route('/user/release_spot')
def release_spot():
    if 'role' not in session or session['role'] != 'user':
        return redirect('/login')
    user_id = session['user_id']
    reservation = Reservation.query.filter_by(user_id=user_id, status='active').first()
    if not reservation:
        flash('No active parking reservation found!')
        return redirect('/user/dashboard')
    spot = ParkingSpot.query.get(reservation.spot_id)
    lot = ParkingLot.query.get(spot.lot_id)
    start_time = datetime.fromisoformat(reservation.parking_timestamp)
    end_time = datetime.now()
    duration_hours = (end_time - start_time).total_seconds() / 3600
    cost = round(duration_hours * lot.price, 2)
    reservation.leaving_timestamp = end_time.isoformat()
    reservation.parking_cost = cost
    reservation.status = 'completed'
    spot.status = 'A'
    db.session.commit()
    flash(f'Parking spot released! Total cost: ₹{cost}')
    return redirect('/user/dashboard')

if __name__ == '__main__':
    app.run(debug=True)
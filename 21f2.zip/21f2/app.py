# app.py - Simple Flask Parking App

from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from datetime import datetime

# Create Flask app
app = Flask(__name__)
app.secret_key = 'my-secret-key'

# Database file name
DATABASE = 'parking_app.db'

# Helper function to connect to database
def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row  # This lets us access columns by name
    return conn

# Create database tables
def create_tables():
    conn = get_db()
    
    # Users table
    conn.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'user',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Parking lots table
    conn.execute('''
        CREATE TABLE IF NOT EXISTS parking_lots (
            id INTEGER PRIMARY KEY,
            prime_location_name TEXT NOT NULL,
            price REAL NOT NULL,
            address TEXT NOT NULL,
            pin_code TEXT NOT NULL,
            maximum_number_of_spots INTEGER NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Parking spots table
    conn.execute('''
        CREATE TABLE IF NOT EXISTS parking_spots (
            id INTEGER PRIMARY KEY,
            lot_id INTEGER NOT NULL,
            spot_number INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'A',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (lot_id) REFERENCES parking_lots (id)
        )
    ''')
    
    # Reservations table
    conn.execute('''
        CREATE TABLE IF NOT EXISTS reservations (
            id INTEGER PRIMARY KEY,
            spot_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            parking_timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
            leaving_timestamp TEXT,
            parking_cost REAL,
            status TEXT NOT NULL DEFAULT 'active',
            FOREIGN KEY (spot_id) REFERENCES parking_spots (id),
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Create admin user if not exists
    admin_exists = conn.execute('SELECT id FROM users WHERE username = ?', ('admin',)).fetchone()
    if not admin_exists:
        conn.execute('INSERT INTO users (username, password, role) VALUES (?, ?, ?)', 
                    ('admin', 'admin123', 'admin'))
        print("Admin user created: username='admin', password='admin123'")
    
    conn.commit()
    conn.close()

# Simple function to create parking spots
def create_parking_spots(lot_id, num_spots):
    conn = get_db()
    for i in range(1, num_spots + 1):
        conn.execute('INSERT INTO parking_spots (lot_id, spot_number, status) VALUES (?, ?, ?)',
                    (lot_id, i, 'A'))
    conn.commit()
    conn.close()

# Home page
@app.route('/')
def home():
    return render_template('home.html')

# Login page
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db()
        user = conn.execute('SELECT * FROM users WHERE username = ? AND password = ?', 
                           (username, password)).fetchone()
        conn.close()
        
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = user['role']
            
            if user['role'] == 'admin':
                return redirect(url_for('admin_dashboard'))
            else:
                return redirect(url_for('user_dashboard'))
        else:
            flash('Wrong username or password!')
    
    return render_template('login.html')

# Register page
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db()
        
        # Check if username already exists
        existing_user = conn.execute('SELECT id FROM users WHERE username = ?', (username,)).fetchone()
        if existing_user:
            flash('Username already taken!')
            conn.close()
            return render_template('register.html')
        
        # Create new user
        conn.execute('INSERT INTO users (username, password, role) VALUES (?, ?, ?)',
                    (username, password, 'user'))
        conn.commit()
        conn.close()
        
        flash('Registration successful! Please login.')
        return redirect(url_for('login'))
    
    return render_template('register.html')

# Logout
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

# Admin Dashboard
@app.route('/admin/dashboard')
def admin_dashboard():
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    
    conn = get_db()
    
    # Get statistics
    total_lots = conn.execute('SELECT COUNT(*) as count FROM parking_lots').fetchone()['count']
    total_spots = conn.execute('SELECT COUNT(*) as count FROM parking_spots').fetchone()['count']
    occupied_spots = conn.execute('SELECT COUNT(*) as count FROM parking_spots WHERE status = "O"').fetchone()['count']
    available_spots = total_spots - occupied_spots
    total_users = conn.execute('SELECT COUNT(*) as count FROM users WHERE role = "user"').fetchone()['count']
    
    # Get all parking lots with spot information
    lots_query = '''
        SELECT 
            pl.*,
            COUNT(ps.id) as total_spots,
            SUM(CASE WHEN ps.status = 'O' THEN 1 ELSE 0 END) as occupied_spots
        FROM parking_lots pl
        LEFT JOIN parking_spots ps ON pl.id = ps.lot_id
        GROUP BY pl.id
    '''
    lots = conn.execute(lots_query).fetchall()
    conn.close()
    
    return render_template('admin_dashboard.html', 
                         total_lots=total_lots,
                         total_spots=total_spots,
                         occupied_spots=occupied_spots,
                         available_spots=available_spots,
                         total_users=total_users,
                         lots=lots)

# Create parking lot
@app.route('/admin/create_lot', methods=['GET', 'POST'])
def create_lot():
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        location_name = request.form['location_name']
        price = float(request.form['price'])
        address = request.form['address']
        pin_code = request.form['pin_code']
        num_spots = int(request.form['num_spots'])
        
        conn = get_db()
        cursor = conn.execute('''
            INSERT INTO parking_lots (prime_location_name, price, address, pin_code, maximum_number_of_spots)
            VALUES (?, ?, ?, ?, ?)
        ''', (location_name, price, address, pin_code, num_spots))
        
        lot_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        # Create parking spots for this lot
        create_parking_spots(lot_id, num_spots)
        
        flash('Parking lot created successfully!')
        return redirect(url_for('admin_dashboard'))
    
    return render_template('create_lot.html')

# Edit parking lot
@app.route('/admin/edit_lot/<int:lot_id>', methods=['GET', 'POST'])
def edit_lot(lot_id):
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    
    conn = get_db()
    lot = conn.execute('SELECT * FROM parking_lots WHERE id = ?', (lot_id,)).fetchone()
    
    if request.method == 'POST':
        location_name = request.form['location_name']
        price = float(request.form['price'])
        address = request.form['address']
        pin_code = request.form['pin_code']
        new_num_spots = int(request.form['num_spots'])
        
        # Get current number of spots
        current_spots = conn.execute('SELECT COUNT(*) as count FROM parking_spots WHERE lot_id = ?', 
                                   (lot_id,)).fetchone()['count']
        
        # Update parking lot
        conn.execute('''
            UPDATE parking_lots 
            SET prime_location_name = ?, price = ?, address = ?, pin_code = ?, maximum_number_of_spots = ?
            WHERE id = ?
        ''', (location_name, price, address, pin_code, new_num_spots, lot_id))
        
        # Handle spot number changes
        if new_num_spots > current_spots:
            # Add more spots
            conn.commit()
            conn.close()
            create_parking_spots(lot_id, new_num_spots - current_spots)
        elif new_num_spots < current_spots:
            # Check if we can remove spots (only available ones)
            available_spots = conn.execute('''
                SELECT COUNT(*) as count FROM parking_spots 
                WHERE lot_id = ? AND status = 'A'
            ''', (lot_id,)).fetchone()['count']
            
            spots_to_remove = current_spots - new_num_spots
            
            if available_spots >= spots_to_remove:
                # Remove available spots
                conn.execute('''
                    DELETE FROM parking_spots 
                    WHERE lot_id = ? AND status = 'A' 
                    ORDER BY spot_number DESC LIMIT ?
                ''', (lot_id, spots_to_remove))
                conn.commit()
                conn.close()
            else:
                conn.close()
                flash('Cannot reduce spots - some spots are occupied!')
                return render_template('edit_lot.html', lot=lot)
        else:
            conn.commit()
            conn.close()
        
        flash('Parking lot updated successfully!')
        return redirect(url_for('admin_dashboard'))
    
    conn.close()
    return render_template('edit_lot.html', lot=lot)

# Delete parking lot
@app.route('/admin/delete_lot/<int:lot_id>')
def delete_lot(lot_id):
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    
    conn = get_db()
    
    # Check if all spots are available
    occupied_count = conn.execute('SELECT COUNT(*) as count FROM parking_spots WHERE lot_id = ? AND status = "O"', 
                                (lot_id,)).fetchone()['count']
    
    if occupied_count > 0:
        flash('Cannot delete parking lot - some spots are occupied!')
    else:
        # Delete the parking lot (spots will be deleted automatically due to foreign key)
        conn.execute('DELETE FROM parking_lots WHERE id = ?', (lot_id,))
        conn.commit()
        flash('Parking lot deleted successfully!')
    
    conn.close()
    return redirect(url_for('admin_dashboard'))

# View parking spots
@app.route('/admin/view_spots/<int:lot_id>')
def view_spots(lot_id):
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    
    conn = get_db()
    lot = conn.execute('SELECT * FROM parking_lots WHERE id = ?', (lot_id,)).fetchone()
    spots = conn.execute('SELECT * FROM parking_spots WHERE lot_id = ? ORDER BY spot_number', 
                        (lot_id,)).fetchall()
    
    # Get reservation information for occupied spots
    reservations_query = '''
        SELECT r.*, u.username, ps.id as spot_id
        FROM reservations r
        JOIN users u ON r.user_id = u.id
        JOIN parking_spots ps ON r.spot_id = ps.id
        WHERE ps.lot_id = ? AND r.status = 'active'
    '''
    reservations_data = conn.execute(reservations_query, (lot_id,)).fetchall()
    
    # Create a dictionary for easy lookup
    reservations = {}
    for res in reservations_data:
        reservations[res['spot_id']] = res
    
    conn.close()
    return render_template('view_spots.html', lot=lot, spots=spots, reservations=reservations)

# View users
@app.route('/admin/users')
def view_users():
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    
    conn = get_db()
    users = conn.execute('SELECT * FROM users WHERE role = "user" ORDER BY created_at DESC').fetchall()
    conn.close()
    
    return render_template('view_users.html', users=users)

# User Dashboard
@app.route('/user/dashboard')
def user_dashboard():
    if 'role' not in session or session['role'] != 'user':
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    conn = get_db()
    
    # Get user's current active reservation
    active_reservation_query = '''
        SELECT r.*, ps.spot_number, pl.prime_location_name, pl.price
        FROM reservations r
        JOIN parking_spots ps ON r.spot_id = ps.id
        JOIN parking_lots pl ON ps.lot_id = pl.id
        WHERE r.user_id = ? AND r.status = 'active'
    '''
    active_reservation = conn.execute(active_reservation_query, (user_id,)).fetchone()
    
    # Get user's parking history
    history_query = '''
        SELECT r.*, ps.spot_number, pl.prime_location_name
        FROM reservations r
        JOIN parking_spots ps ON r.spot_id = ps.id
        JOIN parking_lots pl ON ps.lot_id = pl.id
        WHERE r.user_id = ?
        ORDER BY r.parking_timestamp DESC
        LIMIT 10
    '''
    history = conn.execute(history_query, (user_id,)).fetchall()
    
    # Get available parking lots
    available_lots_query = '''
        SELECT pl.*, COUNT(ps.id) as available_spots
        FROM parking_lots pl
        JOIN parking_spots ps ON pl.id = ps.lot_id
        WHERE ps.status = 'A'
        GROUP BY pl.id
        HAVING COUNT(ps.id) > 0
    '''
    available_lots = conn.execute(available_lots_query).fetchall()
    
    conn.close()
    return render_template('user_dashboard.html', 
                         active_reservation=active_reservation,
                         history=history,
                         available_lots=available_lots)

# Book parking spot
@app.route('/user/book_spot/<int:lot_id>')
def book_spot(lot_id):
    if 'role' not in session or session['role'] != 'user':
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    conn = get_db()
    
    # Check if user already has an active reservation
    active_reservation = conn.execute('SELECT id FROM reservations WHERE user_id = ? AND status = "active"', 
                                    (user_id,)).fetchone()
    
    if active_reservation:
        flash('You already have an active parking reservation!')
        conn.close()
        return redirect(url_for('user_dashboard'))
    
    # Find first available spot in the lot
    available_spot = conn.execute('''
        SELECT * FROM parking_spots 
        WHERE lot_id = ? AND status = 'A' 
        ORDER BY spot_number 
        LIMIT 1
    ''', (lot_id,)).fetchone()
    
    if not available_spot:
        flash('No available spots in this parking lot!')
        conn.close()
        return redirect(url_for('user_dashboard'))
    
    # Create reservation and update spot status
    conn.execute('INSERT INTO reservations (spot_id, user_id, status) VALUES (?, ?, ?)',
                (available_spot['id'], user_id, 'active'))
    conn.execute('UPDATE parking_spots SET status = ? WHERE id = ?', ('O', available_spot['id']))
    
    conn.commit()
    conn.close()
    
    flash('Parking spot booked successfully!')
    return redirect(url_for('user_dashboard'))

# Release parking spot
@app.route('/user/release_spot')
def release_spot():
    if 'role' not in session or session['role'] != 'user':
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    conn = get_db()
    
    # Find active reservation
    active_reservation_query = '''
        SELECT r.*, ps.id as spot_id, pl.price
        FROM reservations r
        JOIN parking_spots ps ON r.spot_id = ps.id
        JOIN parking_lots pl ON ps.lot_id = pl.id
        WHERE r.user_id = ? AND r.status = 'active'
    '''
    active_reservation = conn.execute(active_reservation_query, (user_id,)).fetchone()
    
    if not active_reservation:
        flash('No active parking reservation found!')
        conn.close()
        return redirect(url_for('user_dashboard'))
    
    # Calculate parking cost
    start_time = datetime.fromisoformat(active_reservation['parking_timestamp'])
    end_time = datetime.now()
    duration_hours = (end_time - start_time).total_seconds() / 3600
    cost = round(duration_hours * active_reservation['price'], 2)
    
    # Update reservation
    conn.execute('''
        UPDATE reservations 
        SET leaving_timestamp = ?, parking_cost = ?, status = ?
        WHERE id = ?
    ''', (end_time.isoformat(), cost, 'completed', active_reservation['id']))
    
    # Update spot status
    conn.execute('UPDATE parking_spots SET status = ? WHERE id = ?', 
                ('A', active_reservation['spot_id']))
    
    conn.commit()
    conn.close()
    
    flash(f'Parking spot released! Total cost: ₹{cost}')
    return redirect(url_for('user_dashboard'))

# Initialize database when app starts
if __name__ == '__main__':
    create_tables()
    print("Database initialized successfully!")
    app.run(debug=True)
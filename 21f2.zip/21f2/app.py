from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'my-secret-key'

# Database config
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///parking_app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Models
class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String, unique=True, nullable=False)
    password = db.Column(db.String, nullable=False)
    role = db.Column(db.String, nullable=False, default='user')
    created_at = db.Column(db.DateTime, default=datetime.now)
    reservations = db.relationship('Reservation', backref='user', lazy=True)

class ParkingLot(db.Model):
    __tablename__ = 'parking_lots'
    id = db.Column(db.Integer, primary_key=True)
    prime_location_name = db.Column(db.String, nullable=False)
    price = db.Column(db.Float, nullable=False)
    address = db.Column(db.String, nullable=False)
    pin_code = db.Column(db.String, nullable=False)
    maximum_number_of_spots = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now)
    spots = db.relationship('ParkingSpot', backref='lot', lazy=True)

class ParkingSpot(db.Model):
    __tablename__ = 'parking_spots'
    id = db.Column(db.Integer, primary_key=True)
    lot_id = db.Column(db.Integer, db.ForeignKey('parking_lots.id'), nullable=False)
    spot_number = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String, nullable=False, default='A')
    created_at = db.Column(db.DateTime, default=datetime.now)
    reservations = db.relationship('Reservation', backref='spot', lazy=True)

class Reservation(db.Model):
    __tablename__ = 'reservations'
    id = db.Column(db.Integer, primary_key=True)
    spot_id = db.Column(db.Integer, db.ForeignKey('parking_spots.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    parking_timestamp = db.Column(db.DateTime, default=datetime.now)
    leaving_timestamp = db.Column(db.DateTime)
    parking_cost = db.Column(db.Float)
    status = db.Column(db.String, nullable=False, default='active')

# Create database tables and admin user
def create_tables():
    db.create_all()
    admin = User.query.filter_by(username='admin').first()
    if not admin:
        admin = User(username='admin', password='admin123', role='admin')
        db.session.add(admin)
        db.session.commit()
        print("Admin user created: username='admin', password='admin123'")

# Simple function to create parking spots
def create_parking_spots(lot_id, num_spots):
    lot = ParkingLot.query.get(lot_id)
    if not lot:
        return
    current_spots = ParkingSpot.query.filter_by(lot_id=lot_id).count()
    for i in range(current_spots + 1, current_spots + num_spots + 1):
        spot = ParkingSpot(lot_id=lot_id, spot_number=i, status='A')
        db.session.add(spot)
    db.session.commit()

# Home page
@app.route('/')
def home():
    return render_template('home.html')

# Login page
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username, password=password).first()
        if user:
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            if user.role == 'admin':
                return redirect(url_for('admin_dashboard'))
            else:
                return redirect(url_for('user_dashboard'))
        else:
            flash('Wrong username or password!')
    return render_template('login.html')

# Register page
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already taken!')
            return render_template('register.html')
        user = User(username=username, password=password, role='user')
        db.session.add(user)
        db.session.commit()
        flash('Registration successful! Please login.')
        return redirect(url_for('login'))
    return render_template('register.html')

# Logout
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

# Admin Dashboard
@app.route('/admin/dashboard')
def admin_dashboard():
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    total_lots = ParkingLot.query.count()
    total_spots = ParkingSpot.query.count()
    occupied_spots = ParkingSpot.query.filter_by(status='O').count()
    available_spots = total_spots - occupied_spots
    total_users = User.query.filter_by(role='user').count()
    lots = db.session.query(
        ParkingLot,
        db.func.count(ParkingSpot.id).label('total_spots'),
        db.func.sum(db.case((ParkingSpot.status == 'O', 1), else_=0)).label('occupied_spots')
    ).outerjoin(ParkingSpot).group_by(ParkingLot.id).all()
    # lots is a list of tuples: (ParkingLot, total_spots, occupied_spots)
    return render_template('admin_dashboard.html',
        total_lots=total_lots,
        total_spots=total_spots,
        occupied_spots=occupied_spots,
        available_spots=available_spots,
        total_users=total_users,
        lots=lots)

# Create parking lot
@app.route('/admin/create_lot', methods=['GET', 'POST'])
def create_lot():
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    if request.method == 'POST':
        location_name = request.form['location_name']
        price = float(request.form['price'])
        address = request.form['address']
        pin_code = request.form['pin_code']
        num_spots = int(request.form['num_spots'])
        lot = ParkingLot(
            prime_location_name=location_name,
            price=price,
            address=address,
            pin_code=pin_code,
            maximum_number_of_spots=num_spots
        )
        db.session.add(lot)
        db.session.commit()
        create_parking_spots(lot.id, num_spots)
        flash('Parking lot created successfully!')
        return redirect(url_for('admin_dashboard'))
    return render_template('create_lot.html')

# Edit parking lot
@app.route('/admin/edit_lot/<int:lot_id>', methods=['GET', 'POST'])
def edit_lot(lot_id):
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    lot = ParkingLot.query.get(lot_id)
    if not lot:
        flash('Parking lot not found!')
        return redirect(url_for('admin_dashboard'))
    if request.method == 'POST':
        location_name = request.form['location_name']
        price = float(request.form['price'])
        address = request.form['address']
        pin_code = request.form['pin_code']
        new_num_spots = int(request.form['num_spots'])
        current_spots = ParkingSpot.query.filter_by(lot_id=lot_id).count()
        lot.prime_location_name = location_name
        lot.price = price
        lot.address = address
        lot.pin_code = pin_code
        lot.maximum_number_of_spots = new_num_spots
        db.session.commit()
        if new_num_spots > current_spots:
            create_parking_spots(lot_id, new_num_spots - current_spots)
        elif new_num_spots < current_spots:
            available_spots = ParkingSpot.query.filter_by(lot_id=lot_id, status='A').count()
            spots_to_remove = current_spots - new_num_spots
            if available_spots >= spots_to_remove:
                spots = ParkingSpot.query.filter_by(lot_id=lot_id, status='A').order_by(ParkingSpot.spot_number.desc()).limit(spots_to_remove).all()
                for spot in spots:
                    db.session.delete(spot)
                db.session.commit()
            else:
                flash('Cannot reduce spots - some spots are occupied!')
                return render_template('edit_lot.html', lot=lot)
        flash('Parking lot updated successfully!')
        return redirect(url_for('admin_dashboard'))
    return render_template('edit_lot.html', lot=lot)

# Delete parking lot
@app.route('/admin/delete_lot/<int:lot_id>')
def delete_lot(lot_id):
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    lot = ParkingLot.query.get(lot_id)
    if not lot:
        flash('Parking lot not found!')
        return redirect(url_for('admin_dashboard'))
    occupied_count = ParkingSpot.query.filter_by(lot_id=lot_id, status='O').count()
    if occupied_count > 0:
        flash('Cannot delete parking lot - some spots are occupied!')
    else:
        # Delete all spots and the lot
        ParkingSpot.query.filter_by(lot_id=lot_id).delete()
        db.session.delete(lot)
        db.session.commit()
        flash('Parking lot deleted successfully!')
    return redirect(url_for('admin_dashboard'))

# View parking spots
@app.route('/admin/view_spots/<int:lot_id>')
def view_spots(lot_id):
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    lot = ParkingLot.query.get(lot_id)
    spots = ParkingSpot.query.filter_by(lot_id=lot_id).order_by(ParkingSpot.spot_number).all()
    reservations_data = db.session.query(
        Reservation, User.username, ParkingSpot.id.label('spot_id')
    ).join(User, Reservation.user_id == User.id
    ).join(ParkingSpot, Reservation.spot_id == ParkingSpot.id
    ).filter(ParkingSpot.lot_id == lot_id, Reservation.status == 'active').all()
    reservations = {}
    for res, username, spot_id in reservations_data:
        reservations[spot_id] = {
            'id': res.id,
            'user_id': res.user_id,
            'username': username,
            'parking_timestamp': res.parking_timestamp,
            'leaving_timestamp': res.leaving_timestamp,
            'parking_cost': res.parking_cost,
            'status': res.status
        }
    return render_template('view_spots.html', lot=lot, spots=spots, reservations=reservations)

# View users
@app.route('/admin/users')
def view_users():
    if 'role' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    users = User.query.filter_by(role='user').order_by(User.created_at.desc()).all()
    return render_template('view_users.html', users=users)

# User Dashboard
@app.route('/user/dashboard')
def user_dashboard():
    if 'role' not in session or session['role'] != 'user':
        return redirect(url_for('login'))
    user_id = session['user_id']
    active_reservation = db.session.query(
        Reservation, ParkingSpot.spot_number, ParkingLot.prime_location_name, ParkingLot.price
    ).join(ParkingSpot, Reservation.spot_id == ParkingSpot.id
    ).join(ParkingLot, ParkingSpot.lot_id == ParkingLot.id
    ).filter(Reservation.user_id == user_id, Reservation.status == 'active').first()
    history = db.session.query(
        Reservation, ParkingSpot.spot_number, ParkingLot.prime_location_name
    ).join(ParkingSpot, Reservation.spot_id == ParkingSpot.id
    ).join(ParkingLot, ParkingSpot.lot_id == ParkingLot.id
    ).filter(Reservation.user_id == user_id
    ).order_by(Reservation.parking_timestamp.desc()).limit(10).all()
    available_lots = db.session.query(
        ParkingLot,
        db.func.count(ParkingSpot.id).label('available_spots')
    ).join(ParkingSpot, ParkingLot.id == ParkingSpot.lot_id
    ).filter(ParkingSpot.status == 'A'
    ).group_by(ParkingLot.id
    ).having(db.func.count(ParkingSpot.id) > 0).all()
    return render_template('user_dashboard.html',
        active_reservation=active_reservation,
        history=history,
        available_lots=available_lots)

# Book parking spot
@app.route('/user/book_spot/<int:lot_id>')
def book_spot(lot_id):
    if 'role' not in session or session['role'] != 'user':
        return redirect(url_for('login'))
    user_id = session['user_id']
    active_reservation = Reservation.query.filter_by(user_id=user_id, status='active').first()
    if active_reservation:
        flash('You already have an active parking reservation!')
        return redirect(url_for('user_dashboard'))
    available_spot = ParkingSpot.query.filter_by(lot_id=lot_id, status='A').order_by(ParkingSpot.spot_number).first()
    if not available_spot:
        flash('No available spots in this parking lot!')
        return redirect(url_for('user_dashboard'))
    reservation = Reservation(spot_id=available_spot.id, user_id=user_id, status='active', parking_timestamp=datetime.now())
    available_spot.status = 'O'
    db.session.add(reservation)
    db.session.commit()
    flash('Parking spot booked successfully!')
    return redirect(url_for('user_dashboard'))

# Release parking spot
@app.route('/user/release_spot')
def release_spot():
    if 'role' not in session or session['role'] != 'user':
        return redirect(url_for('login'))
    user_id = session['user_id']
    active_reservation = db.session.query(
        Reservation, ParkingSpot.id.label('spot_id'), ParkingLot.price
    ).join(ParkingSpot, Reservation.spot_id == ParkingSpot.id
    ).join(ParkingLot, ParkingSpot.lot_id == ParkingLot.id
    ).filter(Reservation.user_id == user_id, Reservation.status == 'active').first()
    if not active_reservation:
        flash('No active parking reservation found!')
        return redirect(url_for('user_dashboard'))
    res, spot_id, price = active_reservation
    start_time = res.parking_timestamp
    end_time = datetime.now()
    duration_hours = (end_time - start_time).total_seconds() / 3600
    cost = round(duration_hours * price, 2)
    reservation = Reservation.query.get(res.id)
    reservation.leaving_timestamp = end_time
    reservation.parking_cost = cost
    reservation.status = 'completed'
    spot = ParkingSpot.query.get(spot_id)
    spot.status = 'A'
    db.session.commit()
    flash(f'Parking spot released! Total cost: ₹{cost}')
    return redirect(url_for('user_dashboard'))

# Initialize database when app starts
if __name__ == '__main__':
    with app.app_context():
        create_tables()
        print("Database initialized successfully!")
    app.run(debug=True)